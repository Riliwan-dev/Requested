 <!-- header start -->
 <?php include("include/header.php");?>
 <!-- header end -->

  <!-- Navigation Start -->
  <?php include("include/navigation.php");?>
<!-- Navigation End -->
               
            </div>
        </div>

    <div class="col-one">
        <h2>FREQUENTLY ASKED QUESTIONS</h2>
        <p>We know you've got some question</p>
    </div>


    <div class="question">
        <a href="whoweare.php">Who are We?</a>
        <a href="mode.php">Mode Of Learning</a>
        <a href="benefit.php">After-learning Benefits</a>
    </div>


   <!-- footer start -->
   <?php include("include/footer.php");?>
                <!-- footer end -->