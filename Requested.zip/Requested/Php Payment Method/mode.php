        <!-- header start -->
        <?php include("include/header.php");?>
              <!-- header end -->

               <!-- Navigation Start -->
                <?php include("include/navigation.php");?>
                <!-- Navigation End -->
               
            </div>
        </div>

    <div class="col-one">
        <h2>FREQUENTLY ASKED QUESTIONS</h2>
        <p>We know you've got some question</p>
    </div>


   <div class="back">
       <a href="faq.php">
           <i class="fas fa-light fa-arrow-left"></i>
           <p>back</p>
       </a>
   </div>

   <div class="who">
       Mode of Learning
   </div>

   <main>
       <div class="all">
           <div class="mini">
               <p>What kind of training do we offer?</p>
               <div class="king">
                   <i class="fas fa-light fa-plus "></i>
                    <i class="fas fa-light fa-minus hidden"></i>
                </div>
           </div>
           <div class="fish hide">
               We offer two type of training based on your choice. They are expert on Front-end languages and back-end languages
       </div>

       <div class="all">
        <div class="mini one">
            <p>What's the duration of each course?</p>
            <div class="king">
                <i class="fas fa-light fa-plus  plus"></i>
                 <i class="fas fa-light fa-minus minus hidden"></i>
             </div>
        </div>
        <div class="fish meet hide">
             All our courses last for 6 months
        </div>
    </div>

    <div class="all">
        <div class="mini two">
            <p>What is the Pre-requisite for enrolling in our courses?</p>
            <div class="king">
                <i class="fas fa-light fa-plus  pluss"></i>
                 <i class="fas fa-light fa-minus minuss hidden"></i>
             </div>
        </div>
        <div class="fish giwa hide">
             You don't need any industry based knowledge, you just need a basic computer literacy skill
        </div>
    </div>
   </main>


      <!-- footer start -->
      <?php include("include/footer.php");?>
      <!-- footer end -->
    <script src="all.js"></script>