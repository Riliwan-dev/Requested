 <!-- header start -->
 <?php include("include/header.php");?>
 <!-- header end -->

  <!-- Navigation Start -->
  <?php include("include/navigation.php");?>
<!-- Navigation End -->
               
            </div>
        </div>

    <div class="col-one">
        <h2>FREQUENTLY ASKED QUESTIONS</h2>
        <p>We know you've got some question</p>
    </div>


   <div class="back">
       <a href="faq.php">
           <i class="fas fa-light fa-arrow-left"></i>
           <p>back</p>
       </a>
   </div>

   <div class="who">
    After-learning Benefits
   </div>

   <main>
       <div class="all">
           <div class="mini">
               <p>After completing my course, what next?</p>
               <div class="king">
                   <i class="fas fa-light fa-plus "></i>
                    <i class="fas fa-light fa-minus hidden"></i>
                </div>
           </div>
           <div class="fish hide">
            After completing our course at Gig-tech, if you meet the minimum criteria for assessment, You will be placed on either a paid/unpaid internship to gain relevant internship experience, most times leading to retention based on the performance of the intern in the company.
           </div>
       </div>

       <div class="all">
        <div class="mini one">
            <p>What are the things I will learn after the course?</p>
            <div class="king">
                <i class="fas fa-light fa-plus  plus"></i>
                 <i class="fas fa-light fa-minus minus hidden"></i>
             </div>
        </div>
        <div class="fish meet hide">
            While wrapping up your course at Gig-tech, you will be taught how to create your resume, you will be given orientation on how to approach interviews and also have opportunities to speak to industry experts for different mentorship sessions
        </div>
    </div>

    <!-- <div class="all">
        <div class="mini two">
            <p>After completing my course, what next?</p>
            <div class="king">
                <i class="fas fa-light fa-plus  pluss"></i>
                 <i class="fas fa-light fa-minus minuss hidden"></i>
             </div>
        </div>
        <div class="fish giwa hide">
            After completing our course at Gig-tech, if you meet the minimum criteria for assessment, You will be placed on either a paid/unpaid internship to gain relevant internship experience, most times leading to retention based on the performance of the intern in the company.
        </div>
    </div> -->
   </main>

   <!-- footer start -->
   <?php include("include/footer.php");?>
                <!-- footer end -->
                
    <script src="all.js"></script>