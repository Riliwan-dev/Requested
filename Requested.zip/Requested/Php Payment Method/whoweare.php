 <!-- header start -->
 <?php include("include/header.php");?>
 <!-- header end -->

  <!-- Navigation Start -->
  <?php include("include/navigation.php");?>
<!-- Navigation End -->
               
            </div>
        </div>
 
    <div class="col-one">
        <h2>FREQUENTLY ASKED QUESTIONS</h2>
        <p>We know you've got some question</p>
    </div>


   <div class="back">
       <a href="faq.php">
           <i class="fas fa-light fa-arrow-left"></i>
           <p>back</p>
       </a>
   </div>

   <div class="who">
       Who are We?
   </div>

   <main>
       <div class="all">
           <div class="mini">
               <p>What is Gig-tech?</p>
               <div class="king">
                   <i class="fas fa-light fa-plus "></i>
                    <i class="fas fa-light fa-minus hidden"></i>
                </div>
           </div>
           <div class="fish hide">
                Gig-tech is a team of professionals poised to empower the tech ecosystem by helping tech enthusiast build a rapid tech career by providing access to structured and supervised learning.
           </div>
       </div>

       <div class="all">
        <div class="mini one">
            <p>What is our goal?</p>
            <div class="king">
                <i class="fas fa-light fa-plus  plus"></i>
                 <i class="fas fa-light fa-minus minus hidden"></i>
             </div>
        </div>
        <div class="fish meet hide">
             Gig-tech's goal is to achieve a future of work filled with competent tech professionals.
        </div>
    </div>

    <div class="all">
        <div class="mini two">
            <p>What are courses Gig-tech?</p>
            <div class="king">
                <i class="fas fa-light fa-plus  pluss"></i>
                 <i class="fas fa-light fa-minus minuss hidden"></i>
             </div>
        </div>
        <div class="fish giwa hide">
             Html, CSS/SASS, javascript, react js, php, bootstrap, Wordpress, MYSQL Typescript, Laravel Framework
        </div>
    </div>
   </main>


     <!-- footer start -->
     <?php include("include/footer.php");?>
                <!-- footer end -->
    <script src="all.js"></script>