<nav>
                    <ul class="nav-link">
                        <li class="nav-links"><a href="index.php">home</a></li>
                        <li class="nav-links">
                            <a href="#">courses</a>
                            <div class="dropdown">
                                <div class="item first"><a href="crash.php">Crash Course</a> </div>
                                <div class="item"><a href="PT.php">Personal Training</a> </div>
                                <div class="item last"><a href="Expert.php"> Expert led Courses</a></div>
                            </div>
                        </li>
                        <li class="nav-links"><a href="career.php">career</a></li>
                        <li class="nav-links"><a href="whatwedo.php">what we do</a></li>
                        <li class="nav-links"><a href="about.php">about us</a></li>
                        <li class="nav-links"><a href="faq.php">faq</a></li>
                    </ul>
                    <div class="sign-in">
                        <a href="login.php">sign in</a>
                    </div>
                </nav>