<section class="footer">
            <div class="col">
                <div class="logo"><img src="images/gig.png" alt=""></div>
                <p>We make structured and supervised learning possible. Our students have 100% career leap when they Jump on High rewarding Skill</p>
            </div>
            <div class="col">
                <h3>Quick Links</h3>
                <a href="#">courses</a>
                <a href="career.php">Career</a>
                <a href="whatwedo.php">What we Do</a>
                <a href="about.php">About Us</a>
            </div>
            <div class="col">
                <h3>Contact Us</h3>
                <p>
                    +234 814 7394 829 <br>
                    <a href="www.gigstechsolutions.com.ng">info@gigstechsolutions.com.ng</a> <br>
                    Boladale complex, Lagos-Ibadan Expressway, Academy, Ibadan, Oyo state
                </p>
            </div>
            <div class="col">
                <a href="signup.php">Get started</a>
                <a href="https://www.google.com/maps/place/GigsTech+Solutions+and+Consults/@7.6280095,4.1779562,15.81z/data=!4m7!3m6!1s0x1039db2e2adf76cf:0xb07d4c6964e31a41!4b1!8m2!3d7.628!4d4.1836!16s%2Fg%2F11kqvv86yl?entry=ttu">Roadmap</a>
                
                <!-- <p>Scholarship</p> -->
                <p>Terms and Condition</p>
                <a href="faq.php">FAQ</a>
            </div>
        </section>

        <!-- body end -->



    </div>
<script src="script.js"></script>
</script>
</body>
</html>