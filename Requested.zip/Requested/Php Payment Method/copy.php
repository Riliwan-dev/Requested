<link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="symbol/all.css">
    <link rel="stylesheet" href="crash.css">
    <link rel="stylesheet" href="PT.css">